﻿import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:flutter/material.dart';

class NotificationService {
  static final NotificationService instance = NotificationService._init();
  final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  NotificationService._init();

  Future<void> initialize() async {
    // Initialize timezone
    tz.initializeTimeZones();
    
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTap,
    );

    // Request permissions
    await _requestPermissions();
    
    // Schedule weekend promo notification
    await _scheduleWeekendPromo();
  }

  void _onNotificationTap(NotificationResponse response) {
    // Handle notification tap
    print('Notification tapped: ${response.payload}');
  }

  Future<void> _requestPermissions() async {
    final androidPlugin = _notificationsPlugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    
    if (androidPlugin != null) {
      await androidPlugin.requestNotificationsPermission();
    }

    final iosPlugin = _notificationsPlugin.resolvePlatformSpecificImplementation<
        IOSFlutterLocalNotificationsPlugin>();
    
    if (iosPlugin != null) {
      await iosPlugin.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
    }
  }

  // ðŸ†• Notifikasi Motor Baru - Premium Style
  Future<void> showNewMotorNotification({
    required String motorName,
    required String brand,
    required String price,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      'motor_new_channel',
      'Motor Baru',
      channelDescription: 'Notifikasi saat ada motor baru dijual',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
      color: Color(0xFFDC0000),
      largeIcon: DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
      styleInformation: BigTextStyleInformation(
        'Motor $brand $motorName baru saja dijual dengan harga $price. Buruan cek sebelum kehabisan!',
        contentTitle: 'ðŸï¸ Motor Baru Tersedia!',
        summaryText: 'Children\'s Toys',
      ),
      playSound: true,
      enableVibration: true,
      channelShowBadge: true,
    );

    final iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      subtitle: 'Motor Baru',
    );

    final notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notificationsPlugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      'ðŸï¸ Motor Baru Tersedia!',
      '$brand $motorName - $price',
      notificationDetails,
      payload: 'new_motor',
    );
  }

  // ðŸ”¥ Notifikasi Promo Weekend
  Future<void> _scheduleWeekendPromo() async {
    final androidDetails = AndroidNotificationDetails(
      'promo_channel',
      'Promo Weekend',
      channelDescription: 'Notifikasi promo spesial weekend',
      importance: Importance.high,
      priority: Priority.high,
      color: Color(0xFFDC0000),
      largeIcon: DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
      styleInformation: BigTextStyleInformation(
        'Dapatkan diskon spesial untuk motor pilihan! Promo terbatas hanya weekend ini. Jangan sampai terlewat!',
        contentTitle: 'ðŸ”¥ Promo Weekend Special!',
        summaryText: 'Children\'s Toys',
      ),
      playSound: true,
      enableVibration: true,
    );

    final iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      subtitle: 'Promo Special',
    );

    final notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    // Schedule for every Friday at 18:00
    final now = tz.TZDateTime.now(tz.local);
    var scheduledDate = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      18,
      0,
    );

    // Find next Friday
    while (scheduledDate.weekday != DateTime.friday || scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    await _notificationsPlugin.zonedSchedule(
      1,
      'ðŸ”¥ Promo Weekend Special!',
      'Motor impian Anda menunggu dengan harga terbaik!',
      scheduledDate,
      notificationDetails,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
      payload: 'promo_weekend',
    );
  }

  // â­ Notifikasi Favorit Update
  Future<void> showFavoriteMotorUpdateNotification({
    required String motorName,
    required String oldPrice,
    required String newPrice,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      'favorite_update_channel',
      'Update Motor Favorit',
      channelDescription: 'Notifikasi saat motor favorit ada perubahan',
      importance: Importance.high,
      priority: Priority.high,
      color: Color(0xFFDC0000),
      largeIcon: DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
      styleInformation: BigTextStyleInformation(
        'Motor favorit Anda "$motorName" mengalami perubahan harga dari $oldPrice menjadi $newPrice!',
        contentTitle: 'â­ Update Motor Favorit',
        summaryText: 'Children\'s Toys',
      ),
      playSound: true,
      enableVibration: true,
    );

    final iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notificationsPlugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      'â­ Update Motor Favorit',
      '$motorName: $oldPrice â†’ $newPrice',
      notificationDetails,
      payload: 'favorite_update',
    );
  }

  // ðŸ“ Notifikasi Motor Terdekat
  Future<void> showNearbyMotorNotification({
    required String motorName,
    required String brand,
    required String distance,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      'nearby_motor_channel',
      'Motor Terdekat',
      channelDescription: 'Notifikasi motor baru di sekitar Anda',
      importance: Importance.high,
      priority: Priority.high,
      color: Color(0xFFDC0000),
      largeIcon: DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
      styleInformation: BigTextStyleInformation(
        'Ada motor $brand $motorName yang baru dijual hanya berjarak $distance dari lokasi Anda!',
        contentTitle: 'ðŸ“ Motor Terdekat',
        summaryText: 'Children\'s Toys',
      ),
      playSound: true,
      enableVibration: true,
    );

    final iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notificationsPlugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      'ðŸ“ Motor Terdekat',
      '$brand $motorName - $distance',
      notificationDetails,
      payload: 'nearby_motor',
    );
  }

  // âœ… Notifikasi Motor Berhasil Ditambahkan
  Future<void> showMotorAddedNotification(String motorName) async {
    final androidDetails = AndroidNotificationDetails(
      'motor_added_channel',
      'Motor Ditambahkan',
      channelDescription: 'Konfirmasi motor berhasil ditambahkan',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,
      color: Color(0xFFDC0000),
      largeIcon: DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
      styleInformation: BigTextStyleInformation(
        'Motor "$motorName" telah berhasil ditambahkan ke listing Anda dan dapat dilihat oleh pembeli.',
        contentTitle: 'âœ… Motor Berhasil Ditambahkan!',
        summaryText: 'Children\'s Toys',
      ),
      playSound: true,
      enableVibration: true,
    );

    final iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    final notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notificationsPlugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      'âœ… Motor Berhasil Ditambahkan!',
      'Motor "$motorName" sekarang aktif di listing',
      notificationDetails,
      payload: 'motor_added',
    );
  }

  // ðŸ”” Get Pending Notifications
  Future<int> getPendingNotificationCount() async {
    final pending = await _notificationsPlugin.pendingNotificationRequests();
    return pending.length;
  }

  // ðŸ—‘ï¸ Cancel All Notifications
  Future<void> cancelAllNotifications() async {
    await _notificationsPlugin.cancelAll();
  }
}
